import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Card from './Card'; // Import the Card component
// import './App.css'; // Import your main CSS file for styling

const API_URL = 'https://api.quicksell.co/v1/internal/frontend-assignment';

const App = () => {
  const [tickets, setTickets] = useState([]);
  const [users, setUsers] = useState([]);
  const [groupingOption, setGroupingOption] = useState('status'); // Default grouping by status
  const [sortOption, setSortOption] = useState('priority'); // Default sorting by priority

  useEffect(() => {
    fetchData();
  }, [groupingOption, sortOption]);

  const fetchData = async () => {
    try {
      const response = await axios.get(API_URL);
      setTickets(response.data.tickets);
      setUsers(response.data.users);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const groupAndSortTickets = () => {
    // Implement logic to group and sort tickets based on groupingOption and sortOption
    // Update the tickets state accordingly
    let groupedTickets = [];

    switch (groupingOption) {
      case 'status':
        groupedTickets = groupByStatus(tickets);
        break;
      case 'user':
        groupedTickets = groupByUser(tickets);
        break;
      case 'priority':
        groupedTickets = groupByPriority(tickets);
        break;
      default:
        break;
    }

    const sortedTickets = sortTickets(groupedTickets);

    // Update the tickets state with the grouped and sorted data
    setTickets(sortedTickets);
  };

  const groupByStatus = (tickets) => {
    return tickets.reduce((grouped, ticket) => {
      const status = ticket.status;
      if (!grouped[status]) {
        grouped[status] = [];
      }
      grouped[status].push(ticket);
      return grouped;
    }, {});
  };

  const groupByUser = (tickets) => {
    return tickets.reduce((grouped, ticket) => {
      const userId = ticket.userId;
      if (!grouped[userId]) {
        grouped[userId] = [];
      }
      grouped[userId].push(ticket);
      return grouped;
    }, {});
  };

  const groupByPriority = (tickets) => {
    return tickets.reduce((grouped, ticket) => {
      const priority = ticket.priority;
      if (!grouped[priority]) {
        grouped[priority] = [];
      }
      grouped[priority].push(ticket);
      return grouped;
    }, {});
  };

  const sortTickets = (groupedTickets) => {
    const sortedTickets = {};

    Object.keys(groupedTickets).forEach((key) => {
      sortedTickets[key] = groupedTickets[key].sort((a, b) => {
        if (sortOption === 'priority') {
          return b.priority - a.priority;
        } else if (sortOption === 'title') {
          return a.title.localeCompare(b.title);
        }
        return 0;
      });
    });

    return sortedTickets;
  };

  return (
    <div className="app">
      <div className="controls">
        <button onClick={groupAndSortTickets}>Display</button>
        <select onChange={(e) => setGroupingOption(e.target.value)}>
          <option value="status">By Status</option>
          <option value="user">By User</option>
          <option value="priority">By Priority</option>
        </select>
        <select onChange={(e) => setSortOption(e.target.value)}>
          <option value="priority">Sort by Priority</option>
          <option value="title">Sort by Title</option>
        </select>
      </div>
  
      {/* Render your Kanban board and cards */}
      <div className="kanban-board">
        {Object.keys(tickets).map((key) => (
          <div key={key} className="ticket-group">
            <div className="group-title">{key}</div>
            {Array.isArray(tickets[key]) &&
              tickets[key].map((ticket) => (
                <Card key={ticket.id} data={ticket} type="ticket" />
              ))}
          </div>
        ))}
      </div>
    </div>
  );
  
};

export default App;