// Ticket.js
import React from "react";
import PropTypes from "prop-types";
import "./Ticket.css"; // Import your CSS file for styling

const Ticket = ({ ticket }) => {
  const { title, status, userId, priority } = ticket;

  return (
    <div className="ticket">
      <div className="ticket-header">
        <div className="ticket-title">{title}</div>
        <div className="ticket-priority">Priority: {priority}</div>
      </div>
      <div className="ticket-details">
        <div>Status: {status}</div>
        <div>User: {userId}</div>
      </div>
    </div>
  );
};

Ticket.propTypes = {
  ticket: PropTypes.shape({
    title: PropTypes.string.isRequired,
    status: PropTypes.string.isRequired,
    userId: PropTypes.string.isRequired,
    priority: PropTypes.number.isRequired
  }).isRequired
};

export default Ticket;
