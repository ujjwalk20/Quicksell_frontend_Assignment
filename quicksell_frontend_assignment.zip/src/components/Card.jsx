// Card.js
import React from "react";
import PropTypes from "prop-types";
import "./Card.css"; // Import your CSS file for styling

const Card = ({ data, type }) => {
  const renderContent = () => {
    if (type === "ticket") {
      const { title, status, userId, priority } = data;
      return (
        <div className="card-content">
          <div className="card-title">{title}</div>
          <div className="card-details">
            <div>Status: {status}</div>
            <div>User: {userId}</div>
            <div>Priority: {priority}</div>
          </div>
        </div>
      );
    } else if (type === "user") {
      const { name, available } = data;
      return (
        <div className="card-content">
          <div className="card-title">{name}</div>
          <div
            className={`card-status ${available ? "available" : "unavailable"}`}
          >
            {available ? "Available" : "Unavailable"}
          </div>
        </div>
      );
    }

    return null;
  };

  return <div className={`card ${type}`}>{renderContent()}</div>;
};

Card.propTypes = {
  data: PropTypes.oneOfType([
    PropTypes.shape({
      title: PropTypes.string.isRequired,
      status: PropTypes.string.isRequired,
      userId: PropTypes.string.isRequired,
      priority: PropTypes.number.isRequired
    }),
    PropTypes.shape({
      name: PropTypes.string.isRequired,
      available: PropTypes.bool.isRequired
    })
  ]).isRequired,
  type: PropTypes.oneOf(["ticket", "user"]).isRequired
};

export default Card;
